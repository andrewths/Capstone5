package com.ntuc.controller;

import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;

import com.ntuc.model.Topic;
import com.ntuc.repository.TopicRepository;

@Controller
public class TopicController {

	@Autowired
	private TopicRepository repo;

	@GetMapping("/topics")
	public String listTopics(Model model) {
		List<Topic> listTopics = repo.findAll();
		model.addAttribute("listTopics",listTopics);
		return "topics";
	}


	@GetMapping("/topics/new")
	public String showNewProductForm(Model model) {
		model.addAttribute("topic", new Topic());
		return "topic_form";
	}
	
	@PostMapping("/topic/save")
	public String saveTopic(Topic topic, HttpServletRequest request) {
		repo.save(topic);
		return "redirect:/topics";
	}

	@GetMapping("/topics/edit/{id}")
	public String editTopic(@PathVariable("id") String id, Model model) {
		Topic topic = repo.findById(id).get();
		model.addAttribute("topic", topic);
		return "topic_form";
	}
	

	@GetMapping("/topics/delete/{id}")
	public String deleteTopic(@PathVariable("id") String id, Model model) {
		repo.deleteById(id);
		return "redirect:/topics";
	}
	
	
}
