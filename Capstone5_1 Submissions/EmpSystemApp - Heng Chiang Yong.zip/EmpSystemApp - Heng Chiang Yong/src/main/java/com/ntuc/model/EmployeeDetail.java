package com.ntuc.model;

public class EmployeeDetail {

}
