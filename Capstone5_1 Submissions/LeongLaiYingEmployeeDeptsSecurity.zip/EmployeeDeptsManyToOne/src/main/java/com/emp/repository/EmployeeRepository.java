package com.emp.repository;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.emp.model.Employee;

public interface EmployeeRepository extends JpaRepository<Employee, Integer> {

	@Query("SELECT e FROM Employee e where CONCAT(e.id, e.ename, e.job, e.mgr, e.sal, e.comm, e.hdate, e.depts.dname) like %?1%" )
	public Page<Employee> findAll(String keyword,Pageable pageable);
	
}
