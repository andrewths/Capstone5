package com.emp.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import com.emp.model.Depts;

public interface DeptsRepository extends JpaRepository<Depts, Integer> {

}
