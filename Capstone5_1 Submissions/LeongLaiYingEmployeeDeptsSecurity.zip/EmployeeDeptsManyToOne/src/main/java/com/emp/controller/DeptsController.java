package com.emp.controller;
import com.emp.model.Depts;
import com.emp.repository.DeptsRepository;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;

@Controller
public class DeptsController {
	@Autowired
	private DeptsRepository repo;
	
	@GetMapping("/depts")
	public String listDepts(Model model) {
		List<Depts> listdepts = repo.findAll();
		model.addAttribute("listdepts",listdepts);
		return "depts";
	}
	
	@GetMapping("/depts/new")
	public String ShowDeptsNewForm(Model model) {
		model.addAttribute("depts", new Depts());
		return "depts_form";			
	}
	
	@PostMapping("/depts/save")
	public String saveDepts(Depts depts) {
		repo.save(depts);
		return "redirect:/depts";
	}
}
