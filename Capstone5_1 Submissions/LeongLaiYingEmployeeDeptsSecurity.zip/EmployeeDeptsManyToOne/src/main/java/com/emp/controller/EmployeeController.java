package com.emp.controller;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import com.emp.model.Depts;
import com.emp.model.Employee;
import com.emp.repository.EmployeeRepository;
import com.emp.service.EmployeeService;



import com.emp.repository.DeptsRepository;

@Controller
public class EmployeeController {
	
	@Autowired
	private EmployeeRepository repo;
	
	@Autowired
	private DeptsRepository deptsrepo;
	@Autowired
	private EmployeeService service;
	
	@RequestMapping("/employees")
	public String viewHomePage(Model model) {
		String keyword = null;
		return listByPage(model,1, "id", "asc",keyword);
	}
	
	@GetMapping("/employees/{pageNumber}")
	public String listByPage(Model model,@PathVariable("pageNumber") int currentPage,
			@Param("sortField") String sortField,
			@Param("sortDir") String sortDir,
			@Param("keyword") String keyword)	{
		Page<Employee> page = service.listAll(currentPage,sortField,sortDir,keyword);
		Long totalItems = page.getTotalElements();
		int totalPages = page.getTotalPages();
		List<Employee> listEmployees = page.getContent();
		
		model.addAttribute("currentPage", currentPage);
		model.addAttribute("totalPages", totalPages);
		model.addAttribute("totalItems", totalItems);
		model.addAttribute("listEmployees", listEmployees);
		model.addAttribute("sortField", sortField);
		model.addAttribute("sortDir", sortDir);
		model.addAttribute("sortDir", sortDir);
		model.addAttribute("keyword", keyword);
		
		String reverseSortDir = sortDir.equals("asc") ? "desc" : "asc";
		model.addAttribute("reverseSortDir",reverseSortDir);
		return "employees";
	}
	
	@GetMapping("/employees/new")
	public String showNewEmployeeForm(Model model) {
		List<Depts> listDepts =  deptsrepo.findAll();
		model.addAttribute("employee", new Employee());
		model.addAttribute("listDepts",listDepts);
		return "employee_form";
		
	}
	@PostMapping("/employees/save")
	public String saveEmployee(Employee employee, HttpServletRequest request) {
		/*String[] detailIDs = request.getParameterValues("detailID");
		String[] detailNames = request.getParameterValues("detailName");
		String[] detailValues = request.getParameterValues("detailValue");
		
		for (int i = 0; i< detailNames.length; i++) {
			if(detailIDs != null && detailIDs.length > 0)
				employee.setDetails(Integer.valueOf(detailIDs[i]), detailNames[i], detailValues[i]);
			else {
				employee.addDetail(detailNames[i], detailValues[i]);
		}
		}*/
		repo.save(employee);
		return "redirect:/employees";
	}

	
	@GetMapping("/employees/edit/{id}")
	public String ShowEmployeeEditForm(@PathVariable("id") Integer id, Model model) {
		Employee employee = repo.findById(id).get();
		model.addAttribute("employee", employee);
		List<Depts> listDepts = deptsrepo.findAll();
		model.addAttribute("listDepts", listDepts);
		return "employee_form";
		
	}
	
	@GetMapping("/employees/delete/{id}")
	public String ShowEmployeeDeleteForm(@PathVariable("id") Integer id, Model model) {
		repo.deleteById(id);
		return "redirect:/employees";
	}
	

}
