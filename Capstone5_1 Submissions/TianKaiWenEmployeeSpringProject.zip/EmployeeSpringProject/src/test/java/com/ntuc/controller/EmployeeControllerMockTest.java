package com.ntuc.controller;

import com.ntuc.controller.rest.EmployeeController;
import com.ntuc.model.Department;
import com.ntuc.model.Employee;
import com.ntuc.model.EmployeeDetails;
import com.ntuc.model.JobHistory;
import com.ntuc.service.EmployeeService;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;

import java.time.LocalDate;
import java.util.Arrays;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.BDDMockito.given;
import static org.mockito.BDDMockito.times;
import static org.mockito.Mockito.verify;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultHandlers.print;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

//Mock MVC Test focuses on specific controller
//Only create web beans. @Controller/@ControllerAdvice/Filter/@JsonComponent/WebMvcConfigurer
//No Service/Repository beans created
@WebMvcTest(EmployeeController.class)
class EmployeeControllerMockTest {

    @Autowired
    private MockMvc mockMvc;

    @MockBean
    private EmployeeService employeeService;

    @Test
    void getEmployeesShouldReturn200WithData() throws Exception {
//        given(employeeService.showEmployees()).willReturn(
//                Arrays.asList(new Employee(1L,"Jane","Officer", LocalDate.now(),new Department()
//                        , Arrays.asList(new JobHistory()))));

        mockMvc.perform(get("/employees").accept(MediaType.APPLICATION_JSON))
                .andDo(print())
                .andExpect(status().isOk())
                .andExpect(content().contentType(MediaType.APPLICATION_JSON))
                .andExpect(jsonPath("$[0].empId").value(1))
                .andExpect(jsonPath("$[0].name").value("Jane"))
                .andExpect(jsonPath("$[0].designation").value("Officer"));

        verify(employeeService,times(1)).showEmployees();
    }

    @Test
    void getTopicById() throws Exception {

        mockMvc.perform(get("/emp"))
                .andDo(print())
                .andExpect(status().isInternalServerError())
                .andExpect(mvcResult -> assertTrue(mvcResult.getResolvedException() instanceof RuntimeException))
                .andExpect(mvcResult -> assertEquals(mvcResult.getResolvedException().getMessage(),"test"));

    }

    @Test
    void addEmployees() {
    }

    @Test
    void modifyEmployee() {
    }

    @Test
    void removeEmployee() {
    }
}