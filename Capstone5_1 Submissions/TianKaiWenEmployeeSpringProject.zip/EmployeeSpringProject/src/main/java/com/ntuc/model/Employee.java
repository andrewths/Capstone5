package com.ntuc.model;

import org.springframework.format.annotation.DateTimeFormat;

import javax.persistence.*;
import java.time.LocalDate;
import java.util.HashSet;
import java.util.Objects;
import java.util.Set;

@Entity
public class Employee {

    @Version
    private Long version;

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long empId;

    @Column
    private String name;

    @Column
    private String designation;

    @Column
    @DateTimeFormat(pattern = "yyyy-MM-dd")
    private LocalDate dob;

    @ManyToOne(fetch = FetchType.LAZY)
    //Employee table will have a foreign key column. If no name attribute given then
    //automatically the name will be given as tablename_tablecolumnname
    @JoinColumn(name = "deptId")
    private Department department;

    @OneToMany(fetch = FetchType.LAZY, mappedBy = "employee", cascade = CascadeType.ALL, orphanRemoval = true)
    private Set<JobHistory> jobList = new HashSet<>();

    //Add addJobHistory and removeJobHistory to @OneToMany mapping for bidirectional association
    //to make sure that both sides are synchronized
    public void addJobHistory(JobHistory jobHistory){
        jobList.add(jobHistory);
        jobHistory.setEmployee(this);
    }

    public void removeJobHistory(JobHistory jobHistory){
        jobList.remove(jobHistory);
        jobHistory.setEmployee(null);
    }

    //Although indicate as fetch.lazy but hibernate will still fetch.eager employeedetails
    //because the child entity id must be known when loading the parent entity
    @OneToOne(fetch = FetchType.LAZY, cascade = CascadeType.ALL, mappedBy = "employee")
    private EmployeeDetails employeeDetails;

    public Employee() {
    }

    public Employee(Long empId, String name, String designation, LocalDate dob, Department department, Set<JobHistory> jobList, EmployeeDetails employeeDetails) {
        this.empId = empId;
        this.name = name;
        this.designation = designation;
        this.dob = dob;
        this.department = department;
        this.jobList = jobList;
        this.employeeDetails = employeeDetails;
    }

    public Long getVersion() {
        return version;
    }

    public void setVersion(Long version) {
        this.version = version;
    }

    public Set<JobHistory> getJobList() {
        return jobList;
    }

    public void setJobList(Set<JobHistory> jobList) {
        this.jobList = jobList;
    }

    public EmployeeDetails getEmployeeDetails() {
        return employeeDetails;
    }

    public void setEmployeeDetails(EmployeeDetails employeeDetails) {
        this.employeeDetails = employeeDetails;
    }

    public Long getEmpId() {
        return empId;
    }

    public void setEmpId(Long empId) {
        this.empId = empId;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getDesignation() {
        return designation;
    }

    public void setDesignation(String designation) {
        this.designation = designation;
    }

    public LocalDate getDob() {
        return dob;
    }

    public void setDob(LocalDate dob) {
        this.dob = dob;
    }

    public Department getDepartment() {
        return department;
    }

    public void setDepartment(Department department) {
        this.department = department;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Employee employee = (Employee) o;
        return version.equals(employee.version) &&
                empId.equals(employee.empId);
    }

    @Override
    public int hashCode() {
        return Objects.hash(version, empId);
    }
}
