package com.ntuc.controller.view;

import com.ntuc.model.Department;
import com.ntuc.service.DepartmentService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import java.util.Optional;

@Controller
public class DepartmentViewController {

    @Autowired
    private DepartmentService departmentService;

    @GetMapping("/dept/new")
    public String createDepartmentPage(Model model){
        model.addAttribute("department", new Department());
        return "dept/deptnew";
    }

    @GetMapping("/dept/view")
    public String viewDepartmentPage(Model model){
        model.addAttribute("departmentList", departmentService.showDepartments());
        return "dept/deptview";
    }

    @GetMapping("/dept/view/page")
    public String viewDepartmentPageByPaging(Model model,
                                             @RequestParam("pageNo")Optional<Integer> pageNo,
                                             @RequestParam("dir")Optional<String> dir,
                                             @RequestParam("field")Optional<String> field,
                                             @RequestParam("keyword")Optional<String> keyword){
        int currentPage = pageNo.orElse(1);
        String direction = dir.orElse("asc");
        String fields = field.orElse("deptId");
        String keywords = keyword.orElse("");
        String reverseDirection = direction.equalsIgnoreCase("asc") ? "desc" : "asc";
        Page<Department> deptPage = departmentService.showDepartmentsByPaging(currentPage,direction,fields,keywords);
        int totalPages = deptPage.getTotalPages();
        model.addAttribute("deptPage", deptPage);
        model.addAttribute("totalElements",deptPage.getTotalElements());
        model.addAttribute("currentPage",currentPage);
        model.addAttribute("totalPages", totalPages);
        model.addAttribute("direction",direction);
        model.addAttribute("reverseDirection", reverseDirection);
        model.addAttribute("fields",fields);
        model.addAttribute("keywords",keywords);
        return "dept/deptviewpaging";
    }

    @PostMapping("/dept/save")
    public String createDepartment(Department department){
        departmentService.addDepartment(department);
        return "redirect:/";
    }


}
