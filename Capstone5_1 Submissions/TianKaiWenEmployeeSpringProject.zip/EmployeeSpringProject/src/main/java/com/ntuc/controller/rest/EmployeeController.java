package com.ntuc.controller.rest;

import com.ntuc.model.Employee;
import com.ntuc.service.EmployeeService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpRequest;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.io.File;
import java.util.List;

@RestController
public class EmployeeController {

    @Autowired
    private EmployeeService employeeService;

    @Autowired
    public EmployeeController(EmployeeService employeeService) {
        this.employeeService = employeeService;
    }

    @GetMapping("/employees")
    public ResponseEntity<List<Employee>> showEmployees() {
        return ResponseEntity
                .status(HttpStatus.OK)
                .contentType(MediaType.APPLICATION_JSON)
                .body(employeeService.showEmployees());
    }

    @GetMapping("/employees/{id}")
    public ResponseEntity<Employee> getEmployeeUsingId(@PathVariable Long id) {
        return ResponseEntity
                .status(HttpStatus.OK)
                .contentType(MediaType.APPLICATION_JSON)
                .body(employeeService.showEmployeeById(id).orElse(null));
    }

    @PostMapping("/employees")
    public ResponseEntity<Void> addEmployees(@RequestBody Employee employee, HttpRequest httpRequest) {
        Long id = employeeService.addEmployee(employee);
        return ResponseEntity
                .status(HttpStatus.CREATED)
                .header("Location", httpRequest.getURI() + File.pathSeparator + id)
                .build();
    }

    @PutMapping("/employees/{id}")
    public ResponseEntity<Void> modifyEmployee(@RequestBody Employee employee, @PathVariable Long id) {
        employeeService.modifyEmployee(employee,id);
        return ResponseEntity
                .status(HttpStatus.NO_CONTENT)
                .build();
    }

    @DeleteMapping("/employees/{id}")
    public ResponseEntity<Void> removeEmployee(@PathVariable Long id) {
        employeeService.removeEmployee(id);
        return ResponseEntity
                .status(HttpStatus.NO_CONTENT)
                .build();
    }


    @GetMapping("/emp")
    public ResponseEntity<? extends Object> testException(){

        if(true) throw new RuntimeException("test");

        return ResponseEntity.ok().build();
    }

}
