package com.ntuc.service;

import com.ntuc.model.Employee;
import org.springframework.data.domain.Page;

import java.util.List;
import java.util.Optional;

public interface EmployeeService {

    List<Employee> showEmployees();

    Optional<Employee> showEmployeeById(Long id);

    Long addEmployee(Employee employee);

    void modifyEmployee(Employee employee, Long id);

    void removeEmployee(Long id);

    Page<Employee> showEmployeesByPaging(int pageNo, String dir, String field, String keyword);
}
