package com.ntuc.model;

import javax.persistence.*;
import java.util.HashSet;
import java.util.Objects;
import java.util.Set;

@Entity
public class Company {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long companyId;

    @Column
    private String coyName;

    @Embedded
    private Address coyAddress;

    @ManyToMany(fetch = FetchType.LAZY, cascade = {CascadeType.PERSIST,CascadeType.MERGE})
    @JoinTable(name = "companyDeptMap",
            joinColumns = @JoinColumn(name = "companyId"),
            inverseJoinColumns = @JoinColumn(name = "deptId"))
    private Set<Department> departments = new HashSet<>();

    public Set<Department> getDepartments() {
        return departments;
    }

    public void setDepartments(Set<Department> departments) {
        this.departments = departments;
    }

    public Long getCompanyId() {
        return companyId;
    }

    public void setCompanyId(Long companyId) {
        this.companyId = companyId;
    }

    public String getCoyName() {
        return coyName;
    }

    public void setCoyName(String coyName) {
        this.coyName = coyName;
    }

    public Address getCoyAddress() {
        return coyAddress;
    }

    public void setCoyAddress(Address coyAddress) {
        this.coyAddress = coyAddress;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Company company = (Company) o;
        return companyId.equals(company.companyId) &&
                coyName.equals(company.coyName) &&
                coyAddress.equals(company.coyAddress);
    }

    @Override
    public int hashCode() {
        return Objects.hash(companyId, coyName, coyAddress);
    }
}
