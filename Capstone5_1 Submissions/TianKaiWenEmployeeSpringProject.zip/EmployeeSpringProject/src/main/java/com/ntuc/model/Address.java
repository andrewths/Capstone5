package com.ntuc.model;

import javax.persistence.Embeddable;

@Embeddable
public class Address {

    private String streetName;
    private Long postalCode;

    public String getStreetName() {
        return streetName;
    }

    public void setStreetName(String streetName) {
        this.streetName = streetName;
    }

    public Long getPostalCode() {
        return postalCode;
    }

    public void setPostalCode(Long postalCode) {
        this.postalCode = postalCode;
    }
}
