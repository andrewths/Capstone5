package com.ntuc.security.service;

import com.ntuc.security.model.AppRole;
import com.ntuc.security.model.AppUser;
import com.ntuc.security.repository.AppRoleRepository;
import com.ntuc.security.repository.AppUserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.Set;
import java.util.stream.Collectors;
import java.util.stream.Stream;

@Service
public class UserRoleMapServiceImpl implements UserRoleMapService {

    private AppRoleRepository appRoleRepository;

    private AppUserRepository appUserRepository;

    @Autowired
    public UserRoleMapServiceImpl(AppRoleRepository appRoleRepository, AppUserRepository appUserRepository){
        this.appRoleRepository = appRoleRepository;
        this.appUserRepository = appUserRepository;
    }

    public AppUser getAppUserWithRolesByUserName(String userName){
        AppUser appUser = appUserRepository.findAppUserByUsername(userName);
        Set<AppRole> appRoleSet = appRoleRepository.getAppRolesByAppUsers(appUser);
        appUser.setAppRoles(appRoleSet);
        return appUser;
    }

}
