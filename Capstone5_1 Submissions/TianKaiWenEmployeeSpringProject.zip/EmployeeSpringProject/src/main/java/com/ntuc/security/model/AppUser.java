package com.ntuc.security.model;

import org.springframework.format.annotation.DateTimeFormat;

import javax.persistence.*;
import java.time.LocalDate;
import java.util.HashSet;
import java.util.Set;

@Entity
public class AppUser {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long appUserId;


    @ManyToMany(fetch = FetchType.LAZY, cascade = {CascadeType.MERGE,CascadeType.PERSIST})
    @JoinTable( name = "appUserAppRoleMap",
            joinColumns = @JoinColumn(name = "appUserId"),
            inverseJoinColumns = @JoinColumn(name = "appRoleId")
    )
    private Set<AppRole> appRoles = new HashSet<>();

    @Column
    private String username;

    @Column
    private String password;

    @Column
    private boolean isEnabled;

    @Column
    private boolean isLocked;

    @Column
    @DateTimeFormat(pattern = "yyyy-MM-dd")
    private LocalDate passwordExpiryDate;

    @Column
    @DateTimeFormat(pattern = "yyyy-MM-dd")
    private LocalDate accountExpiryDate;


    public Long getAppUserId() {
        return appUserId;
    }

    public void setAppUserId(Long appUserId) {
        this.appUserId = appUserId;
    }

    public Set<AppRole> getAppRoles() {
        return appRoles;
    }

    public void setAppRoles(Set<AppRole> appRoles) {
        this.appRoles = appRoles;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public boolean isEnabled() {
        return isEnabled;
    }

    public void setEnabled(boolean enabled) {
        isEnabled = enabled;
    }

    public boolean isLocked() {
        return isLocked;
    }

    public void setLocked(boolean locked) {
        isLocked = locked;
    }

    public LocalDate getPasswordExpiryDate() {
        return passwordExpiryDate;
    }

    public void setPasswordExpiryDate(LocalDate passwordExpiryDate) {
        this.passwordExpiryDate = passwordExpiryDate;
    }

    public LocalDate getAccountExpiryDate() {
        return accountExpiryDate;
    }

    public void setAccountExpiryDate(LocalDate accountExpiryDate) {
        this.accountExpiryDate = accountExpiryDate;
    }
}
