package com.ntuc.controller;

import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;

import com.ntuc.model.Sdept;
import com.ntuc.model.Semps;
import com.ntuc.repository.DeptRepository;
import com.ntuc.repository.oldEmpRepository;

@Controller
public class EmpController {

	
	@Autowired
	private oldEmpRepository repo;
	
	@Autowired
	private DeptRepository catrepo;
	
	
	@GetMapping("/emps")
	public String listEmps(Model model) {
		List<Semps> listEmps = repo.findAll();
		model.addAttribute("listemps",listEmps);
		return "semps";
	}
	
	@GetMapping("/emps/new")
	public String showNewEmpForm(Model model) {
		List<Sdept> listDepts =  catrepo.findAll();
		model.addAttribute("semp", new Semps());
		model.addAttribute("listDepts",listDepts);
		return "semp_form";
		
	}
	@PostMapping("/emps/save")
	public String saveEmp(Semps semp, HttpServletRequest request) {
		String[] dIDs = request.getParameterValues("detailID");
		String[] dNames = request.getParameterValues("detailName");
		String[] dValues = request.getParameterValues("detailValue");
		
		for (int i = 0; i< dNames.length; i++) {
			if(dIDs != null && dIDs.length > 0)
				semp.setDetails(Integer.valueOf(dIDs[i]), dNames[i], dValues[i]);
			else {
				semp.addDetails(dNames[i], dValues[i]);
		}
		}
		repo.save(semp);
		return "redirect:/emps";
	}

	
	@GetMapping("/emps/edit/{id}")
	public String ShowEmpEditForm(@PathVariable("id") Integer id, Model model) {
		Semps semp = repo.findById(id).get();
		model.addAttribute("semp", semp);
		List<Sdept> listDepts = catrepo.findAll();
		model.addAttribute("listDepts", listDepts);
		return "semp_form";
		
	}
	
	@GetMapping("/emps/delete/{id}")
	public String ShowEmpDeleteForm(@PathVariable("id") Integer id, Model model) {
		repo.deleteById(id);
		return "redirect:/emps";
	}
	

}
