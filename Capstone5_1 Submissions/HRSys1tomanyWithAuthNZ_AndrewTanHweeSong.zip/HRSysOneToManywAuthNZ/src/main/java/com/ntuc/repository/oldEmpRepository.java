package com.ntuc.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.ntuc.model.Semps;

public interface oldEmpRepository extends JpaRepository<Semps, Integer> {

}
