package com.company.repository;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.company.model.Department;


public interface DepartmentRepository extends JpaRepository<Department, Integer> {
	@Query("SELECT d FROM Department d WHERE CONCAT(d.depid, d.depname) LIKE %?1%")
	public Page<Department> findAll(String keyword, Pageable pageable);

}
