package com.company.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity
public class Department {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Integer depid;
	
	@Column(length = 150, nullable = false, unique=true)
	private String depname;
	
	public Department() {

	}

	public Department(Integer depid, String depname) {
		this.depid = depid;
		this.depname = depname;
	}

	public Integer getDepid() {
		return depid;
	}

	public void setDepid(Integer depid) {
		this.depid = depid;
	}

	public String getDepname() {
		return depname;
	}

	public void setDepname(String depname) {
		this.depname = depname;
	}

	@Override
	public String toString() {
		return  depname;
	}

//	@Override
//	public int hashCode() {
//		final int prime = 31;
//		int result = 1;
//		result = prime * result + ((depid == null) ? 0 : depid.hashCode());
//		result = prime * result + ((depname == null) ? 0 : depname.hashCode());
//		return result;
//	}
//
//	@Override
//	public boolean equals(Object obj) {
//		if (this == obj)
//			return true;
//		if (obj == null)
//			return false;
//		if (getClass() != obj.getClass())
//			return false;
//		Department other = (Department) obj;
//		if (depid == null) {
//			if (other.depid != null)
//				return false;
//		} else if (!depid.equals(other.depid))
//			return false;
//		if (depname == null) {
//			if (other.depname != null)
//				return false;
//		} else if (!depname.equals(other.depname))
//			return false;
//		return true;
//	}
	
}
