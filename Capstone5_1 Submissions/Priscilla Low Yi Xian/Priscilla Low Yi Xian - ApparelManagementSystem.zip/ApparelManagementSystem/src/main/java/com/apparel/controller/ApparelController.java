package com.apparel.controller;

import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;

import com.apparel.model.Apparel;
import com.apparel.model.Category;
import com.apparel.repository.ApparelRepository;
import com.apparel.repository.CategoryRepository;

@Controller
public class ApparelController {

	@Autowired
	private ApparelRepository apparelrepo;

	@Autowired
	private CategoryRepository catrepo;

//	
//	 @GetMapping("/apparel") 
//	 public String listApparel(Model model) {
//	 List<Apparel> listApparel = apparelrepo.findAll();
//	 model.addAttribute("listApparel",listApparel); 
//	 return "apparel"; 
//	 }
//	 

	@GetMapping("/apparel/new")
	public String showNewApparelForm(Model model) {
		List<Category> listcategories = catrepo.findAll();
		model.addAttribute("apparel", new Apparel());
		model.addAttribute("listcategories", listcategories);
		return "apparel_form";

	}

	@PostMapping("/apparel/save")
	public String saveApparel(Apparel apparel, HttpServletRequest request) {
		String[] detailID = request.getParameterValues("detailID");
		String[] detailName = request.getParameterValues("detailName");
		String[] detailValue = request.getParameterValues("detailValue");

		for (int i = 0; i < detailName.length; i++) {
			if (detailID != null && detailID.length > 0)
				apparel.setDetails(Integer.valueOf(detailID[i]), detailName[i], detailValue[i]);
			else {
				apparel.addDetail(detailName[i], detailValue[i]);
			}
		}
		apparelrepo.save(apparel);
		return "redirect:/apparel";
	}

	@GetMapping("/apparel/edit/{id}")
	public String showEditApparelForm(@PathVariable("id") Integer id, Model model) {
		Apparel apparel = apparelrepo.findById(id).get();
		model.addAttribute("apparel", apparel);
		List<Category> listcategories = catrepo.findAll();
		model.addAttribute("listcategories", listcategories);
		return "apparel_form";
	}

	@GetMapping("/apparel/delete/{id}")
	public String deleteApparel(@PathVariable("id") Integer id, Model model) {
		apparelrepo.deleteById(id);
		return "redirect:/apparel";
	}

	@GetMapping("/apparel")
	public String viewHomePage(Model model) {
		String keyword = null;
		return listByPage(model,1, "id", "asc",keyword);
	}
	
	public Page<Apparel> listAll(int pageNumber, String sortField, String sortDir, String keyword) {
		Sort sort = Sort.by(sortField);
		sort = sortDir.equals("asc") ? sort.ascending() : sort.descending();
		Pageable pageable = PageRequest.of(pageNumber - 1, 5, sort); // show 5 records per page
		if (keyword != null) {
			return apparelrepo.findAll(keyword, pageable);
		}
		return apparelrepo.findAll(pageable);

	}

	@GetMapping("apparel/page/{pageNumber}")
	public String listByPage(Model model, @PathVariable("pageNumber") int currentPage,
			@Param("sortField") String sortField, 
			@Param("sortDir") String sortDir, 
			@Param("keyword") String keyword) {
		Page<Apparel> page = listAll(currentPage, sortField, sortDir, keyword);
		Long totalItems = page.getTotalElements();
		int totalPages = page.getTotalPages();
		List<Apparel> listApparel = page.getContent();

		model.addAttribute("currentPage", currentPage);
		model.addAttribute("totalPages", totalPages);
		model.addAttribute("totalItems", totalItems);
		model.addAttribute("listApparel", listApparel);
		model.addAttribute("sortField", sortField);
		model.addAttribute("sortDir", sortDir);
		model.addAttribute("keyword", keyword);

		String reverseSortDir = sortDir.equals("asc") ? "desc" : "asc";
		model.addAttribute("reverseSortDir", reverseSortDir);
		return "apparel";
	}
}
