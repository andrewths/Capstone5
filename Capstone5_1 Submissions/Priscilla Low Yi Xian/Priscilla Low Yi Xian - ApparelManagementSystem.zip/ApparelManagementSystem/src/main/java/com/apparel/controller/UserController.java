package com.apparel.controller;


import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;

import com.apparel.model.Users;
import com.apparel.repository.UserRepository;



@Controller
public class UserController {

	@Autowired
	private UserRepository userrepo;
	
	
	@GetMapping("/user")
	public String listUser(Model model) {
		Iterable<Users> listUser = userrepo.findAll();
		model.addAttribute("listUser",listUser);
		return "users";
	}
	
	@GetMapping("/user/new")
	public String showNewUserForm(Model model) {
		model.addAttribute("user", new Users());
		return "users_form";
		
	}
	
	@PostMapping("/user/save")
	public String saveUser(Users user, HttpServletRequest request) {
		userrepo.save(user);
		return "redirect:/user";
	}
	
	@GetMapping("/user/edit/{id}") 
	public String showEditUserForm(@PathVariable("id") Integer id, Model model) {
		Users user = userrepo.findById(id).get();
		model.addAttribute("user", user);
		return "users_form";
	}
	
	@GetMapping("/user/delete/{id}")
	public String deleteUser(@PathVariable("id") Integer id, Model model) {
		userrepo.deleteById(id);
		return "redirect:/user";
	}
}
