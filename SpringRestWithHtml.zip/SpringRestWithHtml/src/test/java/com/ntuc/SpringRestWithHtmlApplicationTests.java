package com.ntuc;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringRestWithHtmlApplicationTests {

	@Test
	void contextLoads() {
	}

}
