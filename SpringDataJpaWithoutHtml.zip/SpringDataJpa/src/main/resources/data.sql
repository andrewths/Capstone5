insert into topic
values('Java','Java 8', 'Java Detialed');

insert into topic
values('JavaScript','JavaScript ', 'JavaScript Detialed');